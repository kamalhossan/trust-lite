self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "4612e0c35bc3957ee027607a9dec679d",
    "url": "/index.html"
  },
  {
    "revision": "05f7b96e2b45177afeae",
    "url": "/static/css/2.97610728.chunk.css"
  },
  {
    "revision": "b87f553e1f914dbd0d33",
    "url": "/static/css/main.635719cd.chunk.css"
  },
  {
    "revision": "05f7b96e2b45177afeae",
    "url": "/static/js/2.02802a1f.chunk.js"
  },
  {
    "revision": "b87f553e1f914dbd0d33",
    "url": "/static/js/main.70000a02.chunk.js"
  },
  {
    "revision": "378be0eab5cddffc5e87",
    "url": "/static/js/runtime-main.862645ae.js"
  },
  {
    "revision": "e76cb07798376f3f218de961b986157d",
    "url": "/static/media/aminul.e76cb077.jpg"
  },
  {
    "revision": "9835a5ad0c41d379fad4182d6a6edbc8",
    "url": "/static/media/babul.9835a5ad.jpg"
  },
  {
    "revision": "201710cf75b1bbc3262ee70f24441a5c",
    "url": "/static/media/combo.201710cf.jpg"
  },
  {
    "revision": "6b23d48d1ef22271eaec36822d1c94e1",
    "url": "/static/media/farabi.6b23d48d.jpg"
  },
  {
    "revision": "d223bc157e230a0f22cd6c0a41afcaec",
    "url": "/static/media/homemaderedy.d223bc15.jpg"
  },
  {
    "revision": "023adaae96cdecd6dcfa0a6555a1c2f0",
    "url": "/static/media/howitworks.023adaae.jpg"
  },
  {
    "revision": "51dbffdb1335f270efee0bfaa6c95b58",
    "url": "/static/media/loader.51dbffdb.svg"
  },
  {
    "revision": "0291d8fd46e9224685c3f020b7662ffd",
    "url": "/static/media/logo.0291d8fd.png"
  },
  {
    "revision": "72f58e4f817959264bd0a39fd6b71625",
    "url": "/static/media/porag.72f58e4f.jpg"
  },
  {
    "revision": "b0f54d151dd32b18690dffba6fcb0763",
    "url": "/static/media/productmarket.b0f54d15.jpg"
  },
  {
    "revision": "f035bd1a075de1d6f2fe318586ac47d4",
    "url": "/static/media/ready-to-cook.f035bd1a.jpg"
  },
  {
    "revision": "04eb8fc57f27498e5ae37523e3bfb2c7",
    "url": "/static/media/revicons.04eb8fc5.woff"
  },
  {
    "revision": "17629a5dfe0d3c3946cf401e1895f091",
    "url": "/static/media/revicons.17629a5d.ttf"
  },
  {
    "revision": "2feb69ccb596730c72920c6ba3e37ef8",
    "url": "/static/media/revicons.2feb69cc.eot"
  },
  {
    "revision": "95b7162339e3f9dcfbf665b3abb14263",
    "url": "/static/media/serious.95b71623.jpg"
  },
  {
    "revision": "af20c6ff284f6ded80f3d555843e4963",
    "url": "/static/media/shafi.af20c6ff.jpg"
  },
  {
    "revision": "43074fb93ea49a59027dba6e84e42715",
    "url": "/static/media/wholesale.43074fb9.jpg"
  },
  {
    "revision": "3b04dbcb0a167e707ae8367208662fc4",
    "url": "/static/media/why.3b04dbcb.jpg"
  }
]);